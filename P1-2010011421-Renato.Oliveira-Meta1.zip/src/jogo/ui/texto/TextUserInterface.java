package jogo.ui.texto;

import java.io.IOException;
import java.util.*;

import jogo.logica.Jogo;
import jogo.logica.JogoCareTaker;
import jogo.logica.dados.Jogador.Humano;
import jogo.logica.dados.Jogador.Jogador;
import jogo.logica.dados.Jogador.Virtual;
import jogo.logica.dados.MiniJogo.MiniJogo;
import jogo.logica.dados.memento.Memento;
import jogo.logica.util.GerirFicheiros;

/**
 *
 * @author Jose Marinho
 */
public class TextUserInterface {

    private JogoCareTaker j;
    private Scanner s;

    public TextUserInterface(JogoCareTaker jogoCareTaker) {
        j = jogoCareTaker;
        s=new Scanner(System.in);
    }

    private void mostraTabuleiro() { System.out.println(j); }

    private void obterInputEnquantoNaoAcaba()
    {
        int value;

        System.out.println();
        System.out.println("************** Jogo Terminou *****************");
        mostraTabuleiro();
        System.out.println();

        GerirFicheiros.gravarJogo(j, j.getNomeJogo());
        System.out.println("1-Iniciar Novo Jogo");
        System.out.println("2-Sair");
        System.out.print("> ");

        while(!s.hasNextInt()) s.next();

        value=s.nextInt();

        if(value==1){
            j.iniciar();
        }else if(value==2){
            System.exit(0);
        }

    }

    private void obterInputInicial() throws IOException, ClassNotFoundException {
        int value;
        String nomeFicheiro;
        JogoCareTaker jogoACarregar;

        System.out.println("---------------------------------");
        System.out.println("-------- QUATRO EM LINHA --------");
        System.out.println("---------------------------------");

        System.out.println("[0] Iniciar Jogo ");
        System.out.println("[1] Replay ");
        System.out.println("[2] Carregar Jogo");
        System.out.println("[3] Terminar Jogo ");
        System.out.print("> ");

        while (!s.hasNextInt()) s.next();

        value = s.nextInt();

        while(value <0 || value > 3)
        {
            System.out.println("Opção Inválida. Escolha opção válida!");
            System.out.print("> ");
            value = s.nextInt();
        }

        if (value == 0)
            obterDadosJogadores();
        else if(value == 1)
        {
            System.out.print("Nome do jogo: ");
            nomeFicheiro = s.next();
            if( ((jogoACarregar = GerirFicheiros.carregarJogo(nomeFicheiro)) == null))
                System.out.println("Erro ao ler o ficheiro " + nomeFicheiro);
            else
            {
                mostraDadosReplay(jogoACarregar);
            }
        }
        else if(value == 2)
        {
            System.out.print("Nome do jogo: ");
            nomeFicheiro = s.next();
            if( ((jogoACarregar = GerirFicheiros.carregarJogo(nomeFicheiro)) == null))
                System.out.println("Erro ao ler o ficheiro " + nomeFicheiro);
            else
                j = jogoACarregar;
        }
        else
            j.terminarJogo();

    }

    private void mostraDadosReplay(JogoCareTaker jogo) throws IOException, ClassNotFoundException
    {
        List<String> dados = jogo.dadosReplay();

        for (String s: dados)
        {
            System.out.println(s);
        }
    }

    private void obterDadosJogadores()
    {
        int value;
        String nome;
        Character identificador;

        System.out.println("[******** JOGADORES *********");
        System.out.println("[0] CPU vs CPU: ");
        System.out.println("[1] JOG vs CPU: ");
        System.out.println("[2] JOG vs JOG: ");
        System.out.print("> ");

        while(!s.hasNextInt()) s.next();
        value = s.nextInt();

        switch (value)
        {
            case 0:
                j.inserirJogador(new Virtual("Virtual1",'1'));
                j.inserirJogador(new Virtual("Virtual2",'2'));
                break;
            case 1:
                j.inserirJogador(new Virtual("Virtual1",'V'));
                System.out.println("Nome de Jogador 1: ");
                System.out.print("> ");
                nome = s.next();

                System.out.println("Identificador Jogador 1: ");
                System.out.print("> ");

                identificador = s.next().charAt(0);
                j.inserirJogador(new Humano(nome, identificador));
                break;
            case 2:
                System.out.println("Nome de Jogador 1: ");
                System.out.print("> ");
                nome = s.next();

                System.out.println("Identificador Jogador 1: ");
                System.out.print("> ");

                identificador = s.next().charAt(0);
                j.inserirJogador(new Humano(nome, identificador));

                System.out.println("\nNome de Jogador 2: ");
                System.out.print("> ");

                do {
                    nome = s.next();
                    if(j.getJogadores().get(0).getNome().equals((nome)))
                        System.out.println("Nome de Jogador 2 deve ser diferente de Jogador1 ");
                } while(j.getJogadores().get(0).getNome().equals((nome)));

                System.out.println("Identificador Jogador 2: ");
                System.out.print("> ");

                do {
                    identificador = s.next().charAt(0);
                    if(j.getJogadores().get(0).getIdentificador().equals((identificador)))
                        System.out.println("Identificador de Jogador 2 deve ser diferente de Jogador1 ");
                } while(j.getJogadores().get(0).getIdentificador().equals((identificador)));

                j.inserirJogador(new Humano(nome,identificador));
                break;
        }


    }

    private void obterInputProximaJogada()
    {
        int value;
        String nomeFicheiro;

        Jogador atualmenteAJogar = j.getAtualmenteAJogar();

        if(atualmenteAJogar instanceof Virtual) {
            System.out.println();
            System.out.println("Vez de Jogador: " + atualmenteAJogar.getNome());
            j.jogar(atualmenteAJogar, 0);
            return;
        }else {

            if(j.getJogoAtual().getResultado())
                obterInputPecaEspecial();

            System.out.println("\n\n---------------------------------");
            mostraTabuleiro();
            System.out.println();
            System.out.println("Créditos: " + atualmenteAJogar.getCreditos());
            System.out.println();

            System.out.println("[0] Jogar");
            System.out.println("[1] Voltar Atrás");
            System.out.println("[2] Usar Peça Especial");
            System.out.println("[3] Guardar Jogo");
            System.out.println("[4] Terminar Jogo");
            System.out.print("> ");

            while (!s.hasNextInt()) s.next();

            value = s.nextInt();

            while(value < 0 || value > 4)
            {
                System.out.println("Opção Inválida. Escolha opção válida!");
                System.out.print("> ");
                value = s.nextInt();
            }

            if (value == 0)
            {
                if(!j.verificaInicioMiniJogo()) {
                    obterInputColunaJogar();
                }
                else{
                        System.out.println("\n\n---------------------------------");

                        System.out.println("Deseja Jogar um mini Jogo?");
                        System.out.println("1 - Sim   2 - Não ");
                        System.out.print("> ");
                        while(!s.hasNextInt()) s.next();

                        value = s.nextInt();

                        if(value == 1)
                            j.iniciarMiniJogo(j.getAtualmenteAJogar());
                        else
                            obterInputColunaJogar();
                }

            }
            else if(value == 1)
            {
                System.out.println("Quantos créditos pretende usar?");
                System.out.print("> ");
                while(!s.hasNextInt()) s.next();
                value = s.nextInt();

                if(value > 0)
                {
                    if(j.verificaPossivelVoltarAtras(value))
                    {
                        j.undo(value);
                        j.getAtualmenteAJogar().setnJogada(0);
                        j.getAtualmenteAJogar().setPecaEspecial(false);
                        j.getAtualmenteAJogar().setCreditos(value);
                        System.out.println("Andou " + value + " jogadas para trás!");
                    }
                }
            }
            else if( value == 2)
                obterInputPecaEspecial();
            else if( value == 3)
            {
                System.out.print("Nome de jogo para gravar: ");
                nomeFicheiro = s.next();
                if(!GerirFicheiros.gravarJogo(j, nomeFicheiro))
                    System.out.println("Erro a gravar jogo!");
                else
                    System.out.println("Jogo " + nomeFicheiro + " gravado com sucesso!");
            }
            else if(value == 4)
                j.terminarJogo();
        }

    }

    private void obterInputColunaJogar()
    {
        int value;
        Jogador atualmenteAJogar = j.getAtualmenteAJogar();

        System.out.println("Número da Coluna ");
        System.out.print("> ");

        while (!s.hasNextInt()) s.next();

        value = s.nextInt();

        while (value <= 0 || value > 7) {
            System.out.println("Opção Inválida. Escolha opção válida!");
            System.out.print("> ");
            value = s.nextInt();
        }

        j.jogar(atualmenteAJogar, value);
    }

    private void obterInputMiniJogoMatematica()
    {
        String valor;
        MiniJogo jogoAtual = j.getJogoAtual();

        int tempo = 0;

        tempo = jogoAtual.getTempoPassado();
        System.out.println("Tem " + (jogoAtual.getTempo() - tempo) + " segundos!");
        System.out.print(jogoAtual);

        while (!s.hasNext()) s.next();

        valor = s.next();

        j.inserirRespostaMiniJogo(valor);
        System.out.println();

    }

    private void obterInputMiniJogoPalavras()
    {

        String valor;
        MiniJogo jogoAtual = j.getJogoAtual();

        System.out.println(jogoAtual);
        System.out.print("> ");

        s = new Scanner(System.in);

        valor = s.nextLine();
        j.inserirRespostaMiniJogo(valor);

    }

    private void obterInputPecaEspecial()
    {
        int value;
        Jogador jogadorAtual = j.getAtualmenteAJogar();

        System.out.println("\n\n---------------------------------");

        System.out.println("Deseja Usar Peça Especial?");
        System.out.println("1 - Sim   2 - Não ");
        System.out.print("> ");
        while(!s.hasNextInt()) s.next();
        value = s.nextInt();

        if(value == 1) {
            if (!jogadorAtual.getPecaEspecial()) {
                System.out.println("Ainda não adquiriu a peça especial!");
            }
            else
            {
                System.out.println("\n\n---------------------------------");

                System.out.println("Indique a coluna");
                System.out.print("> ");
                while(!s.hasNextInt()) s.next();
                value = s.nextInt();

                while (value < 0 || value > j.getLarguraTabuleiro())
                {
                    System.out.println("Coluna inválida");
                    System.out.print("> ");
                }

                j.usarPecaEspecial(jogadorAtual, value);

            }
        }
        else {
            j.getJogoAtual().setResultado(false);
            obterInputProximaJogada();
        }
    }

    public void showMsgLog()
    {
        if(j.getMsgLog().size()>0){
            for(String msg:j.getMsgLog()){
                System.out.println("---> " + msg);
            }
        }
    }

    public void run() throws IOException, ClassNotFoundException {

        while (true)
        {
            System.out.println();
            showMsgLog();
            j.clearMsgLog();

            if (j.estaAguardarInicio()) {
                obterInputInicial();
            }else if (j.estaAguardarInputJogada()) {
                obterInputProximaJogada();
            }else if (j.estaAguardarFimMiniJogoMatematica()) {
                obterInputMiniJogoMatematica();
            } else if (j.estaAguardarFimMiniJogoPalavras()) {
                obterInputMiniJogoPalavras();
            }else if (j.terminouJogo()) {
                obterInputEnquantoNaoAcaba();
            }

        }
    }


}
