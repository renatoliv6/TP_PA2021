package jogo;

import jogo.logica.Jogo;
import jogo.logica.JogoCareTaker;
import jogo.ui.texto.TextUserInterface;

import java.io.File;

import java.io.IOException;

public class Main {


    public static void main(String[] args) throws IOException, ClassNotFoundException {

        TextUserInterface ui = new TextUserInterface(new JogoCareTaker());
        ui.run();
    }

}

