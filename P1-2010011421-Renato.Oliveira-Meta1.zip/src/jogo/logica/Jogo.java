package jogo.logica;

import jogo.logica.dados.DadosJogo;
import jogo.logica.dados.Jogador.Jogador;
import jogo.logica.dados.MiniJogo.MiniJogo;
import jogo.logica.dados.memento.IOriginator;
import jogo.logica.dados.memento.Memento;
import jogo.logica.estados.*;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author Renato Oliveira
 */
public class Jogo implements Serializable, IOriginator
{
    public static final long serialVersionUID =  1L;

    private DadosJogo dadosJogo;
    private IEstado estado;

    public Jogo()
    {
        dadosJogo = new DadosJogo();
        estado = new AguardaInicio(dadosJogo);
    }


    public boolean estaAguardarInicio() { return estado instanceof AguardaInicio; }

    public boolean estaAguardarInputJogada() { return estado instanceof AguardaJogada; }

    public boolean estaAguardarFimMiniJogoMatematica()
    {
        return estado instanceof AguardaFimMiniJogoMatematica;
    }

    public boolean estaAguardarFimMiniJogoPalavras() { return estado instanceof AguardaFimMiniJogoPalavras; }

    public boolean terminouJogo()
    {
        return estado instanceof TerminarJogo;
    }

    //------------------------------ Methods that enable accessing the data/status of the game ----------------------------

    public List<Jogador> getJogadores() { return dadosJogo.getJogadores(); }

    public Jogador getAtualmenteAJogar() { return dadosJogo.getAtualmenteAJogar(); }

    public List<String> getMsgLog()
    {
        return dadosJogo.getMsgLog();
    }

    public MiniJogo getJogoAtual() { return dadosJogo.getMiniJogoAtual(); }

    public boolean getMiniJogoADecorrer(){ return dadosJogo.getMiniJogoADecorrer(); }

    public int getLarguraTabuleiro() { return dadosJogo.getTabuleiro().LARGURA; }

    public String getNomeJogo() { return dadosJogo.nome; }

    public boolean verificaPossivelVoltarAtras(int nCreditos) { return dadosJogo.verificaPossivelVoltarAtras(nCreditos); }

    public boolean verificaInicioMiniJogo() { return dadosJogo.verificaInicioMinijogo(); }

    public MiniJogo ativarMiniJogo() { return dadosJogo.ativarMiniJogo(); }

    public void setDadosJogo(DadosJogo dadosJogo) { this.dadosJogo = dadosJogo;}

    public void clearMsgLog() { dadosJogo.clearMsgLog(); }

    public boolean jogoTerminou(Jogador jogador) { return dadosJogo.jogoTerminou(jogador);}

    @Override
    public String toString() { return dadosJogo.toString(); }

    //--------------------- Methods that trigger events/actions in the finite state machine  -----------------------

    public void inserirJogador(Jogador jogador) { estado = estado.inserirJogador(jogador); }

    public void iniciar() { estado = estado.iniciar(); }

    public void iniciarMiniJogo(Jogador jogador) { estado = estado.iniciarMiniJogo(jogador); }

    public void inserirRespostaMiniJogo(String resposta) { estado = estado.inserirRespostaMiniJogo(resposta); }

    public void terminarJogo() { estado = estado.terminarJogo(); }

    public void jogar(Jogador jogador, int ncoluna) { estado = estado.jogar(jogador, ncoluna); }

    public void usarPecaEspecial(Jogador jogador, int ncoluna){ estado = estado.usarPecaEspecial(jogador, ncoluna); }

    @Override
    public Memento createMemento() throws IOException { return new Memento(estado); }

    @Override
    public void restoreMemento(Memento memento) throws IOException, ClassNotFoundException
    {
        this.estado = ((IEstado) memento.getSnapshot());
        dadosJogo = estado.getDadosJogo();

    }
}
