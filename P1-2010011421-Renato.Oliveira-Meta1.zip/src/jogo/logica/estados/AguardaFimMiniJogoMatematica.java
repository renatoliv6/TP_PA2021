package jogo.logica.estados;

import jogo.logica.dados.DadosJogo;
import jogo.logica.dados.MiniJogo.MiniJogo;

public class AguardaFimMiniJogoMatematica extends EstadoAdapter
{
    public AguardaFimMiniJogoMatematica(DadosJogo dadosJogo) { super(dadosJogo); }

    @Override
    public IEstado inserirRespostaMiniJogo(String resposta)
    {
        DadosJogo dadosJogo = getDadosJogo();
        MiniJogo jogo = dadosJogo.getMiniJogoAtual();

        jogo.insereResposta(resposta);
        jogo.gerarInputJogo();
        jogo.setFinalTemporizador();

        int tempo = jogo.getTempoPassado();

        if(tempo <= jogo.getTempo())
            return this;
        else {
            if (jogo.getGanhou()) {
                dadosJogo.addMsgLog("Ganhou a peça especial!!");
                dadosJogo.getAtualmenteAJogar().setPecaEspecial(true);
                dadosJogo.setMiniJogoADecorrer(false);
                return new AguardaJogada(getDadosJogo());
            } else {
                dadosJogo.addMsgLog("Perdeu o jogo e a sua vez de jogar!!");
                dadosJogo.trocaJogadores();
                dadosJogo.setMiniJogoADecorrer(false);
                return new AguardaJogada(getDadosJogo());
            }
        }

    }

}
