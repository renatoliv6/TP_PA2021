package jogo.logica.estados;

import jogo.logica.dados.DadosJogo;
import jogo.logica.dados.Jogador.Jogador;
import jogo.logica.dados.MiniJogo.Matematica;
import jogo.logica.dados.MiniJogo.MiniJogo;
import jogo.logica.dados.Peca;
import jogo.logica.util.GerirFicheiros;

public class AguardaJogada extends EstadoAdapter
{
    public AguardaJogada(DadosJogo dadosJogo) { super(dadosJogo); }

    @Override
    public IEstado jogar(Jogador jogador, int nColuna)
    {
        DadosJogo dadosJogo = getDadosJogo();
        int colunaPecaJogada;

        colunaPecaJogada = dadosJogo.addPeca(nColuna, jogador);

        if(dadosJogo.jogoTerminou(jogador)) {
            return new TerminarJogo(getDadosJogo());
        }
        if(colunaPecaJogada == -1)
        {
            dadosJogo.addMsgLog("Escolha nova coluna para jogar!");
            return this;
        }

        if(dadosJogo.jogoTerminou(jogador))
            return new TerminarJogo(getDadosJogo());

        jogador.setnJogada((jogador.getnJogada()+1));

        dadosJogo.trocaJogadores();

        dadosJogo.addMsgLog("Jogador " + jogador.getNome() + " jogou na coluna " + colunaPecaJogada);

        return new AguardaJogada(getDadosJogo());
    }

    @Override
    public IEstado usarPecaEspecial(Jogador jogador, int coluna)
    {
        DadosJogo dadosJogo = getDadosJogo();
        jogador.setPecaEspecial(false);
        dadosJogo.getMiniJogoAtual().setResultado(false);

        if(dadosJogo.usarPecaEspecial(coluna))
            dadosJogo.addMsgLog("Peça especial utilizada!");
        else
            dadosJogo.addMsgLog("Erro ao usar peça especial!");

        return new AguardaJogada(getDadosJogo());
    }

    @Override
    public IEstado iniciarMiniJogo(Jogador jogador)
    {
        DadosJogo dadosJogo = getDadosJogo();

        MiniJogo jogo = dadosJogo.ativarMiniJogo();

        dadosJogo.addMsgLog("A iniciar Mini Jogo!");

        if(jogo instanceof Matematica)
            return new AguardaFimMiniJogoMatematica(getDadosJogo());
        else
            return new AguardaFimMiniJogoPalavras(getDadosJogo());
    }

    @Override
    public IEstado terminarJogo() { return new TerminarJogo(getDadosJogo()); }

}
