package jogo.logica.estados;

import jogo.logica.dados.DadosJogo;
import jogo.logica.dados.Jogador.Jogador;

import java.io.IOException;
import java.util.List;

public interface IEstado
{
    IEstado iniciar();
    IEstado iniciarMiniJogo(Jogador jogador);
    IEstado terminarJogo();
    IEstado jogar(Jogador jogador, int coluna);
    IEstado inserirJogador(Jogador jogador);
    IEstado inserirRespostaMiniJogo(String resposta);
    IEstado usarPecaEspecial(Jogador jogador, int coluna);

    DadosJogo getDadosJogo();
}
