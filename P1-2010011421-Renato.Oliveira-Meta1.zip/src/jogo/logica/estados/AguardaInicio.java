package jogo.logica.estados;

import jogo.logica.dados.DadosJogo;
import jogo.logica.dados.Jogador.Jogador;
import jogo.logica.dados.Peca;

import java.util.Collections;

public class AguardaInicio extends EstadoAdapter
{
    public AguardaInicio(DadosJogo dadosJogo) { super(dadosJogo); }

    @Override
    public IEstado inserirJogador(Jogador jogador)
    {
        DadosJogo dadosJogo = getDadosJogo();
        dadosJogo.addJogador(jogador);

        if(getDadosJogo().getJogadores().size() == 2)
        {
            Collections.shuffle(dadosJogo.getJogadores());
            dadosJogo.setJogadorAtual();
            dadosJogo.setProximoJogar();
            dadosJogo.addMsgLog("Jogadores sorteados, o primeiro a jogar é: " + dadosJogo.getAtualmenteAJogar().getNome());
            return new AguardaJogada(getDadosJogo());
        }

        return this;
    }

    @Override
    public IEstado terminarJogo() { return new TerminarJogo(getDadosJogo()); }
}
