package jogo.logica.estados;

import jogo.logica.dados.DadosJogo;
import jogo.logica.util.GerirFicheiros;

public class TerminarJogo extends EstadoAdapter
{
    public TerminarJogo(DadosJogo dadosJogo) { super(dadosJogo); }

    @Override
    public IEstado iniciar()
    {
        getDadosJogo().initialize();
        return new AguardaInicio(getDadosJogo());
    }

    @Override
    public String toString() { return "Jogo Terminou"; }
}
