package jogo.logica;

import jogo.logica.Jogo;
import jogo.logica.dados.DadosJogo;
import jogo.logica.dados.Jogador.Jogador;
import jogo.logica.dados.MiniJogo.MiniJogo;
import jogo.logica.dados.Peca;
import jogo.logica.dados.memento.Memento;
import jogo.logica.estados.*;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class JogoCareTaker implements Serializable
{
    public static final long serialVersionID = 1;

    private Jogo jogo;

    private List<Memento> historicoMementosJogadas = new ArrayList<>();
    private List<Memento> historicoMementosReplay = new ArrayList<>();

    public JogoCareTaker() throws IOException { this.jogo = new Jogo(); }

    public boolean estaAguardarInicio() { return jogo.estaAguardarInicio(); }

    public boolean estaAguardarInputJogada() { return jogo.estaAguardarInputJogada(); }

    public boolean estaAguardarFimMiniJogoMatematica()
    {
        return jogo.estaAguardarFimMiniJogoMatematica();
    }

    public boolean estaAguardarFimMiniJogoPalavras() { return jogo.estaAguardarFimMiniJogoPalavras(); }

    public boolean terminouJogo()
    {
        return jogo.terminouJogo();
    }

    //------------------------------ Methods that enable accessing the data/status of the game ----------------------------

    public List<Jogador> getJogadores() { return jogo.getJogadores(); }

    public Jogador getAtualmenteAJogar() { return jogo.getAtualmenteAJogar(); }

    public List<String> getMsgLog()
    {
        return jogo.getMsgLog();
    }

    public MiniJogo getJogoAtual() { return jogo.getJogoAtual(); }

    public int getLarguraTabuleiro() { return jogo.getLarguraTabuleiro(); }

    public boolean getMiniJogoADecorrer(){ return jogo.getMiniJogoADecorrer(); }

    public String getNomeJogo() { return jogo.getNomeJogo(); }

    public MiniJogo ativarMiniJogo() { return jogo.ativarMiniJogo(); }

    public void clearMsgLog() { jogo.clearMsgLog(); }

    @Override
    public String toString() { return jogo.toString(); }

    //--------------------- Methods that trigger events/actions in the finite state machine  -----------------------

    public void inserirJogador(Jogador jogador)
    {
        jogo.inserirJogador(jogador);
        gravaMementoReplay();
    }

    public void iniciar()
    {
        jogo.iniciar();
        gravaMementoReplay();
    }

    public void iniciarMiniJogo(Jogador jogador)
    {
        jogo.iniciarMiniJogo(jogador);
        gravaMementoReplay();
    }

    public void inserirRespostaMiniJogo(String resposta)
    {
        jogo.inserirRespostaMiniJogo(resposta);
        gravaMementoReplay();
    }

    public void terminarJogo()
    {
        gravaMementoReplay();
        jogo.terminarJogo();
    }

    public void jogar(Jogador jogador, int nColuna)
    {
        gravaMementoJogadas();
        jogo.jogar(jogador, nColuna);
        gravaMementoReplay();
    }

    public void usarPecaEspecial(Jogador jogador, int ncoluna)
    {
        jogo.usarPecaEspecial(jogador, ncoluna);
        gravaMementoReplay();
    }

    public boolean verificaPossivelVoltarAtras(int nCreditos) { return jogo.verificaPossivelVoltarAtras(nCreditos); }

    public boolean verificaInicioMiniJogo() { return jogo.verificaInicioMiniJogo(); }

    public List<String> dadosReplay() throws IOException, ClassNotFoundException {
        List<String> dados = new ArrayList<>();
        Jogo jogoReplay = new Jogo();
        StringBuilder s;

        List<Memento> historicoMementos = historicoMementosReplay;
        for(Memento m: historicoMementos)
        {
            s = new StringBuilder();
            jogoReplay.restoreMemento(m);

            if(!jogoReplay.getMiniJogoADecorrer()) {
                s.append(jogoReplay);
                s.append("\n");
            }

            if(jogoReplay.getMsgLog().size()>0){
                for(String msg:jogoReplay.getMsgLog()){
                    s.append("---> " + msg);
                }
            }

            dados.add(s.toString());
        }

        return dados;
    }

    public void gravaMementoJogadas()
    {
        try {
            historicoMementosJogadas.add(jogo.createMemento());
        }catch (IOException ex)
        {
            System.out.println("gravaMemento: " + ex);
            historicoMementosJogadas.clear();
        }

    }

    public void gravaMementoReplay()
    {

        try {
            historicoMementosReplay.add(jogo.createMemento());
        }catch (IOException ex)
        {
            System.out.println("gravaMemento: " + ex);
            historicoMementosReplay.clear();
        }

    }

    public void undo(int qtd)
    {
        if(historicoMementosJogadas.isEmpty())
            return;

        try
        {
            Memento anterior = historicoMementosJogadas.get(historicoMementosJogadas.size()-qtd);
            jogo.restoreMemento(anterior);
            historicoMementosJogadas.subList(historicoMementosJogadas.size()-qtd, historicoMementosJogadas.size());

        }catch (IOException | ClassNotFoundException ex)
        {
            System.out.println("voltar atrás: "+ ex);
            historicoMementosJogadas.clear();
        }

    }
}
