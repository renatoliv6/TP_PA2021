package jogo.logica.util;

import jogo.logica.Jogo;
import jogo.logica.JogoCareTaker;
import jogo.logica.dados.DadosJogo;

import java.io.*;

public class GerirFicheiros
{

    public static boolean gravarJogo(JogoCareTaker jogo, String nomeJogo)
    {
        ObjectOutputStream out = null;

        try {

            out = new ObjectOutputStream(new FileOutputStream(nomeJogo +".bin"));
            out.writeUnshared(jogo);
            out.flush();
        }
        catch (IOException e)
        {
            return false;
        }finally
        {
            try {
                if(out != null) out.close();
            }catch (IOException e){}
        }

        return true;
    }

    public static JogoCareTaker carregarJogo(String fileName) throws IOException, ClassNotFoundException
    {
        JogoCareTaker jogo = null;
        ObjectInputStream in = null;

        try
        {
            in = new ObjectInputStream(new FileInputStream(fileName));

            jogo = (JogoCareTaker) in.readObject();


        }catch (Exception e)
        {
            return null;
        }
        finally {
            try {
                if(in != null) in.close();
            }catch (IOException e){}
        }


        return jogo;
    }
}
