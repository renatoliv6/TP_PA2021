package jogo.logica.dados.Jogador;

import jogo.logica.dados.DadosJogo;
import jogo.logica.dados.Jogador.Jogador;
import jogo.logica.dados.Peca;
import jogo.logica.dados.Tabuleiro;

import java.util.List;

public class Humano extends Jogador {
    public Humano(String nome, Character id) { super(nome, id); }

    @Override
    public int getnJogada (){ return nJogada;}

    @Override
    public boolean getPecaEspecial() { return pecaEspecial; }

    @Override
    public int getCreditos() { return creditos; }

    @Override
    public void setnJogada(int nJogada) { super.nJogada = nJogada; }

    @Override
    public void setPecaEspecial(boolean ativar) { pecaEspecial = ativar; }

    @Override
    public boolean setCreditos(int qtdTirar)
    {
        if((creditos- qtdTirar) < 0)
            return false;

        creditos -= qtdTirar;
        return true;
    }


    @Override
    public int calcularProximaJogada(Tabuleiro tabuleiro){ return -1; };
}
