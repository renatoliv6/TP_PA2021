package jogo.logica.dados.memento;

import java.io.IOException;

public interface IOriginator
{
    public Memento createMemento() throws IOException;
    public void restoreMemento(Memento memento) throws IOException, ClassNotFoundException;
}
