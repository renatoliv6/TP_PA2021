package jogo.logica.dados;

import java.io.Serializable;

public class Peca implements Serializable
{
    public static final long serialVersionID = 1;

    int linha;
    int coluna;
    boolean especial;
    char identificador;

    public Peca(Peca peca)
    {
        this.linha = peca.linha;
        this.coluna = peca.coluna;
        this.identificador = peca.identificador;
        this.especial = peca.especial;
    }

    public Peca(int linha, int coluna, char identificador)
    {
        especial = false;
        this.linha = linha;
        this.coluna = coluna;
        this.identificador = identificador;
    }

    public void setLinha(int l) { linha = l; }
    public void setColuna(int c) { coluna = c; }

    public int getLinha() { return linha; }
    public int getColuna() { return coluna; }

    public char getIdentificador() { return identificador; }

    @Override

    public String toString()
    {
        return Character.toString(identificador);
    }
}
