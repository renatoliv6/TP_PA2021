package jogo.ui.gui;

public class Constants {
    public static final int BUTTON_WIDTH_HEIGHT = 25;

    public static final int CANVAS_WIDTH = 500;
    public static final int CANVAS_HEIGHT = 500;

    public static final int ESPACO_ENTRE_ITEMS_ESCOLHA_COLUNA = 16;
    public static final int ESPACO_ENTRE_ITEMS_ESCOLHA_ID = 5;


    private Constants() {}
}
